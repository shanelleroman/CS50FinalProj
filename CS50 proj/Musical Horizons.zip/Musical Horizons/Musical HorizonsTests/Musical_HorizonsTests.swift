//
//  Musical_HorizonsTests.swift
//  Musical HorizonsTests
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 11/22/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import XCTest
@testable import Musical_Horizons

class Musical_HorizonsTests: XCTestCase {
    
    // Tests to confirm that the Meal initializer returns when no name or a negative rating is provided.
    func testChordInfoInitialization () {
        // success case
        let potentialItem = ChordInfo(chordName: "Sample", photo: nil)
        XCTAssertNotNil(potentialItem)
        
        // fail case
        let noName = ChordInfo(chordName: "", photo: nil)
        XCTAssertNil(noName, "Empty name is invalid")
        
        
        
    }
    
}
