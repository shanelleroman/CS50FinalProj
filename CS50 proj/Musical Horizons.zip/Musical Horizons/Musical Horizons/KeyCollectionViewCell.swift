//
//  KeyCollectionViewCell.swift
//  MusicalHorizons
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/7/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class KeyCollectionViewCell: UICollectionViewCell {
    
   
    @IBOutlet weak var keyLabel: UILabel!
    
    // MARK: actions
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
   
    }
    

    
}
