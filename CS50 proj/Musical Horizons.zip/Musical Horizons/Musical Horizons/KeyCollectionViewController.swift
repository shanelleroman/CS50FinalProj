//
//  KeyCollectionViewController.swift
//  MusicalHorizons
//  Displays different keys that the user can select
//  Sends information about key selected to mainViewController to change key
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/6/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class KeyCollectionViewController: UICollectionViewController {
    
    // MARK: properties
    var keys = [Key]()
    

    // MARK: functions
    override func viewDidLoad() {
        super.viewDidLoad()

        // Register cell classes
        self.collectionView!.registerClass(KeyCollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        // Load Keys
        loadKeys()


    }
    
    // Initialize key objects and adds them to an array
    func loadKeys() {
        let photo1 = UIImage(named: "key")!
        
        // Initialize key objects
        let a = Key(keyName: "A", image: photo1)
        let aFlat = Key(keyName: "A Flat", image: photo1)
        let b = Key(keyName: "B", image: photo1)
        let bFlat = Key(keyName: "B Flat", image: photo1)
        let c = Key(keyName: "C", image: photo1)
        let cSharp = Key(keyName: "C Sharp", image: photo1)
        let d = Key(keyName: "D", image: photo1)
        let e = Key(keyName: "E", image: photo1)
        let eFlat = Key(keyName: "E Flat", image: photo1)
        let f = Key(keyName: "F", image: photo1)
        let fSharp = Key(keyName: "F Sharp", image: photo1)
        let g = Key(keyName: "G", image: photo1)
        
        // add to keys array
        keys += [a, aFlat, b, bFlat, c, cSharp, d, e, eFlat, f, fSharp, g]
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    // MARK: UICollectionViewDataSource

    // Return number of different sections
    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {

        return 1
    }


    // Return number of items in each section
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

        return keys.count
    }
    
    // Populates collection view cells with key objects
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        // initializes cell
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("KeyTableViewCell", forIndexPath: indexPath) as! KeyCollectionViewCell
        
        
        // find correct object in keys array
        let key = keys[indexPath.row]
        
        
        // configures the cell information
        cell.keyLabel.text = key.keyName
       
        
        // configures the cell aesethetics
        cell.keyLabel.textColor = UIColor.whiteColor()
        cell.layer.borderWidth = 0.5
        cell.layer.cornerRadius = 3
        cell.backgroundColor = UIColor.blackColor()
          
        return cell


    }

    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        // Check correct segue
        if segue.identifier == "changedKey" {
            let navigController = segue.destinationViewController as? UINavigationController
            let mainViewController = navigController?.topViewController as? MainViewController
            
            // Make sure sender correct type
            if let selectedKeyCell = sender as? KeyCollectionViewCell {
                
                // Select the Key object and pass to a variable in the destinationViewController
                let indexPath = collectionView?.indexPathForCell(selectedKeyCell)!
                let selectedKey = keys[indexPath!.row] // type Key
                let selectedKeyName = selectedKey.keyName
                mainViewController?.keyName = selectedKeyName
   

            }
        
            
        }
        
        
    }


}
