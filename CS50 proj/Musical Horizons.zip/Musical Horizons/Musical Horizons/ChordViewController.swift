//
//  ChordViewController.swift
//  Musical Horizons
//
//  Created by Shanelle Roman on 12/2/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//


import UIKit



class ChordViewController: UIViewController {
    
    //MARK: properties
    @IBOutlet weak var indivChordLabel: UILabel!
    @IBOutlet weak var textInfo: UITextView!

    
    var chord: ChordInfo?

    
    //MARK: load the window
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set the label
        indivChordLabel.text = chord?.chordName
        
        // read the chord description in from local file
        loadTextView((chord?.chordName)!)

    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // performs a backwards segue to chordList
    func backtoChordList(alert: UIAlertAction!) {
        performSegueWithIdentifier("backwards", sender: nil)
    }
    
    // displays alert when an error occurs
    func displayErrorMessage() {
        let alertError = UIAlertController(title: "Oops!", message: "Could not find the requested chord ifnormation", preferredStyle: UIAlertControllerStyle.Alert)
        alertError.addAction(UIAlertAction(title: "Go Back", style: UIAlertActionStyle.Default, handler: backtoChordList))
    }
    
    // loads the information about the chord
    func loadTextView(chordName: String) {
        // replace spaces with _ to find Text_Files
        let newChordName = chordName.stringByReplacingOccurrencesOfString(" ", withString: "_")
        
        // finds the path for the text file where chordInfo is stored
        var path: String = ""
        if let location = NSBundle.mainBundle().pathForResource(newChordName, ofType: "txt") {
            path += location
        }
        else {
            displayErrorMessage()
        }
        
        // reads fileContent
        let fileContent = try? NSString(contentsOfFile: path, encoding: NSUTF8StringEncoding) as String!
        if fileContent != nil {
                textInfo.text = fileContent
            }
        else {
            displayErrorMessage()
        }

    
    }
    
    
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


