//
//  ChordViewController.swift
//  Musical Horizons
//  Displays further information about specific theory object
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/2/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//


import UIKit



class ChordViewController: UIViewController {
    
    //MARK: properties
    @IBOutlet weak var indivChordLabel: UILabel!
    @IBOutlet weak var textInfo: UITextView!

    
    var chord: ChordInfo?

    
    //MARK: load the window
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set the label
        indivChordLabel.text = chord?.chordName
        
        // read the chord description in from local file
        loadTextView((chord?.chordName)!)

    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Performs a backwards segue to chordList
    func backtoChordList(alert: UIAlertAction!) {
        performSegueWithIdentifier("backwards", sender: nil)
    }
    
    // Displays alert when an error occurs
    func displayErrorMessage() {
        let alertError = UIAlertController(title: "Oops!", message: "Could not find the requested chord ifnormation", preferredStyle: UIAlertControllerStyle.Alert)
        alertError.addAction(UIAlertAction(title: "Go Back", style: UIAlertActionStyle.Default, handler: backtoChordList))
    }
    
    // Loads the information about the chord
    func loadTextView(chordName: String) {
        // Replace spaces with _ to find Text_Files
        let newChordName = chordName.stringByReplacingOccurrencesOfString(" ", withString: "_")
        
        // Finds the path for the text file where chordInfo is stored
        var path: String = ""
        if let location = NSBundle.mainBundle().pathForResource(newChordName, ofType: "txt") {
            path += location
        }
        else {
            displayErrorMessage()
        }
        
        // Reads fileContent
        let fileContent = try? NSString(contentsOfFile: path, encoding: NSUTF8StringEncoding) as String!
        if fileContent != nil {
                textInfo.text = fileContent
                textInfo.font = UIFont(name: "Didot", size: 12)
            }
        else {
            displayErrorMessage()
        }

    
    }
    
    
}