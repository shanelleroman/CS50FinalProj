//
//  ChordInfoTableViewController.swift
//  Musical Horizons
//  Loads TheoryTableViewCells filled with chordInfo objects
//  Passes information about chordInfo object selected to destinationViewController
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/1/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class ChordInfoTableViewController: UITableViewController {
    
    // MARK: properties
    var chords = [ChordInfo]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // loads the initial table view
        loadChordInfo()
    }
    
    // Loads the initial table views of the different chords and the theory behind them
    func loadChordInfo () {
        let photo1 = UIImage(named: "photo")!
        
        // initialize ChordInfo objects
        let background = ChordInfo (chordName: "Background Info", photo: photo1)!
        let chord1 = ChordInfo(chordName: "Major Chord", photo: photo1)!
        let chord2 = ChordInfo(chordName: "Minor Chord", photo: photo1)!
        let chord3 = ChordInfo(chordName: "Dominant 7th Chord", photo: photo1)!
        
        // adds them to chords array
        chords += [background, chord1, chord2, chord3]
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    // returns the number of sections
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    // returns the number of rows
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chords.count
    }

    // configures and returns a table view cell
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        // Table view cells are reused and should be dequeued using a cell identifier.
        let cellIdentifier = "TheoryTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! TheoryTableViewCell
        
        // Fetch appropriate theory view cell 
        let chord = chords[indexPath.row]
        
        // Set view to display data fom ChordInfo
        cell.chordLabel.text = chord.chordName
        cell.photoImageView.image = chord.photo

        return cell
    }
    
    
    // MARK: - Navigation

    // Transfers data about which chordInfo object was selected
    // Passed from ChordInfoTableViewController to ChordViewController
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        // Make sure it's the right segue
       if segue.identifier == "individualChord" {
        
        let chordDetailViewController = segue.destinationViewController as? ChordViewController
    
        // Make sure sender is the correct type
        if let selectedChordCell = sender as? TheoryTableViewCell {
            
            // Select the ChordInfo object and pass to a variable in destinationViewController
            let indexPath = tableView.indexPathForCell(selectedChordCell)!
            let selectedChord = chords[indexPath.row] // type ChordInfo
            chordDetailViewController?.chord = selectedChord
            }
        
        }
        
        
    }


}
