//
//  TheoryTableViewCell.swift
//  Musical Horizons
//  Draws the content of each theory cell
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 11/30/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class TheoryTableViewCell: UITableViewCell {
    
    //MARK: properties
    @IBOutlet weak var chordLabel: UILabel!
    @IBOutlet weak var photoImageView: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
