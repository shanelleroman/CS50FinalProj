//
//  ChordInfo.swift
//  Musical Horizons
//  Class for the creation of ChordInfo objects 
//  ChordInfo object = populate the list of different theory topics
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/2/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class ChordInfo {
    
    //MARK: properties
    var chordName: String
    var photo: UIImage?
    
    //MARK: initalization
    init?(chordName: String, photo: UIImage?) {
        self.chordName = chordName
        self.photo = photo
        
        // Initialization should fail if there is no chordName
        if chordName.isEmpty {
            return nil
        }
    }
    
    
    
    
}

