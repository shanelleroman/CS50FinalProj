//
//  MainViewController.swift
//  MusicalHorizons
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/4/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit
import AVFoundation

class MainViewController: UIViewController, AVAudioPlayerDelegate {
    
    // MARK: properties
    var audioPlayer = AVAudioPlayer()
    var keyName: String?
    @IBOutlet weak var keyLabel: UILabel!
    var key4Chord: String?
    @IBOutlet weak var piano: UIImageView!
    var charliePlaying: Bool = false
    
    // MARK: Actions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Checks everytime the page loads what key should be played
        changedKey()
        
        // Make piano image sensitive to touch
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:Selector("imageTapped:"))
        piano.userInteractionEnabled = true
        piano.addGestureRecognizer(tapGestureRecognizer)
    }
    
    // Determines what key should be played
    func changedKey() {

        // If home page, default key = C
        if keyName == nil {
            keyName = "C"
            if let name = keyName {
                keyLabel.text = "Key: \(name)"
            }
        }
        // different key - set KeyLabel and set a key parameter
        else {
            if let label = keyName {
                keyLabel.text = "Key: \(label)"
                key4Chord = label
            }
        }
    }
    

    // Plays the music when image tapped
    func imageTapped(img: AnyObject)
    {
        
        // Declares file name
        let songName = "Linus_and_Lucy"
        
        // Retrieves file URL
        let soundURL =  NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource(songName, ofType: "mp3")!)
        
        // Plays sound
        do {
            // set up audioPlayer
            audioPlayer = try AVAudioPlayer(contentsOfURL: soundURL)
            audioPlayer.delegate = self
            audioPlayer.volume = 1.0
            
            if audioPlayer.playing {
                audioPlayer.stop()
            }
            
            // play the sound
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            charliePlaying = true
            
        }catch  {
            let alert = UIAlertController (title: "Oops!", message: "Error retrieving audio file", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: .Default, handler: {
                (action: UIAlertAction!) in alert.dismissViewControllerAnimated(true, completion: nil)
            }))
            
            presentViewController(alert, animated: true, completion: nil)
        }
        
    }
    
    // Plays chord
    func playSound (chordName: String, key: String) {
        
        // Formats correct file name
        let key1 = key.stringByReplacingOccurrencesOfString(" ", withString: "")
        let realName =  key1 + "_" + chordName
        
        // Retrieves sound file's URL
        let soundURL =  NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource(realName, ofType: "mp3")!)
        // Plays sound
        do {
            // set up audioPlayer
            audioPlayer = try AVAudioPlayer(contentsOfURL: soundURL)
            audioPlayer.delegate = self
            audioPlayer.volume = 1.0
            
            // play the sound
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            
        }catch  {
            let alert = UIAlertController (title: "Oops!", message: "Sorry, there was an error retrieving the audio file", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: .Default, handler: {
                (action: UIAlertAction!) in alert.dismissViewControllerAnimated(true, completion: nil)
            }))
            
            presentViewController(alert, animated: true, completion: nil)

        }
    }


    // Triggered by major button
    @IBAction func playMajor(sender: AnyObject) {
        playSound("Major", key: keyName!)

    }

    // Triggered by minor button
    @IBAction func playMinor(sender: AnyObject) {
        playSound("Minor", key: keyName!)
    }
    

    // Triggered by Dominant 7th Button
    @IBAction func playDom(sender: AnyObject) {
        playSound("7", key:  keyName!)
    }


    @IBAction func pauseCharlie(sender: AnyObject) {
        if charliePlaying {
            audioPlayer.stop()
        }
        
    }
    
    
    // If music file could not be read
    func audioPlayerDecodeErrorDidOccur(player: AVAudioPlayer,
        error: NSError?) {
            // alerts the viewer to the problem
            let alertError = UIAlertController(title: "Oops!", message: "Sorry the music could not be found", preferredStyle: UIAlertControllerStyle.Alert)
            alertError.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
 
    }
    
}


