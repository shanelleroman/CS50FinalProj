//
//  MenuTableViewController.swift
//  MusicalHorizons
//  Displays menu of possible actions that can be accessed from home page
//
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/4/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class MenuTableViewController: UITableViewController {
    
    // MARK: properties
    var items = [MenuItem]()
    
    // MARK: functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // loads the initial table view
        loadMenuItems()

    }
    
    func loadMenuItems() {
        let photo1 = UIImage(named: "icon")!
        
        // initialize MenuItem objects
        let theory = MenuItem(name: "Learn More!", photo: photo1)!
        let diffChord = MenuItem(name: "Pick a Different Key!", photo: photo1)!
        let guess = MenuItem(name: "Guess the Chord!", photo: photo1)!

        
        // add them to items array
        items += [theory, diffChord, guess]

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
 
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
 
        return items.count
    }

    // configures and returns a table view cell
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        // Table view cells are reused and should be dequeued using a cell identifier.
        let cellIdentifier = "MenuTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! MenuTableViewCell
        
        // Fetch appropriate MenuTableViewCell
        let item = items[indexPath.row]
        
        //Set view to display data from MenuItem
        cell.textLabel!.text = item.name
        cell.imageView!.image = item.photo
        

        return cell
    }
    
    // Performs different segues based on which cell is tapped
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        switch(indexPath.row) {
        case 0:
            performSegueWithIdentifier("theory", sender: self)
        case 1:
            performSegueWithIdentifier("newKey", sender: self)
        case 2:
            performSegueWithIdentifier("guess", sender: self)
        default:
            break
        }
        
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        // If seguing to GuessViewController, generates a random integer
        if segue.identifier == "guess" {
            
            // Accesses the correct viewController
            let navigController = segue.destinationViewController as? UINavigationController
            let guessViewController = navigController?.topViewController as? GuessViewController
            
            // Determines what chord is played
            let chordNum = Int(arc4random_uniform(3))
            guessViewController?.number = chordNum
            
            
        }
        
    
    }


}
