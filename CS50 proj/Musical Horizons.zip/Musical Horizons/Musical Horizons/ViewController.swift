//
//  ViewController.swift
//  Musical Horizons
//
//  Created by Shanelle Roman on 12/3/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate {
    
    // MARK: properties
    var audioPlayer = AVAudioPlayer()

    // MARK: Actions
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // plays chord
    func playSound (soundName: String) {
        
        // Retrieves sound file's URL
        let soundURL =  NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource(soundName, ofType: "mp3")!)
       
        // Plays sound
        do {
            // set up audioPlayer
            audioPlayer = try AVAudioPlayer(contentsOfURL: soundURL)
            audioPlayer.delegate = self
            audioPlayer.volume = 1.0
            
            // play the sound
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            
        
        }catch  {
            print("Error retrieving audio file")
        }
    }
    

    @IBAction func playMajor(sender: AnyObject) {
        playSound("C_Major")
    }
  
    @IBAction func playMinor(sender: AnyObject) {
        playSound("C_Minor")
    }
    
    @IBAction func playDom(sender: AnyObject) {
        playSound("C_7")
    }
    
    // if music file could not be read
    func audioPlayerDecodeErrorDidOccur(player: AVAudioPlayer,
        error: NSError?) {
            // alerts the viewer to the problem
            let alertError = UIAlertController(title: "Oops!", message: "Sorry the music could not be found", preferredStyle: UIAlertControllerStyle.Alert)
            alertError.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        // Do I delete this or not?
    }

}
