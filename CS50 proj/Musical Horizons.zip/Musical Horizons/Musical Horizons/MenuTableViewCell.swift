//
//  MenuTableViewCell.swift
//  MusicalHorizons
//
//  Created by Shanelle Roman on 12/4/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class MenuTableViewCell: UITableViewCell {

    // MARK: properties
    @IBOutlet weak var label: UILabel!

   
  
    
    
    
    // MARK: actions
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
