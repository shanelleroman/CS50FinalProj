//
//  MenuTableViewController.swift
//  MusicalHorizons
//
//  Created by Shanelle Roman on 12/4/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class MenuTableViewController: UITableViewController {
    
    // MARK: properties
    var items = [MenuItem]()

    override func viewDidLoad() {
        super.viewDidLoad()
        print("view did Load")
        
        // loads the initial table view
        loadMenuItems()
        print("Menu items have loaded")

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    func loadMenuItems() {
        let photo1 = UIImage(named: "photo")!
        
        // initialize MenuItem objects
        let theory = MenuItem(name: "Learn More!", photo: photo1)!
        let diffChord = MenuItem(name: "Pick a Different Key!", photo: photo1)!
        let guess = MenuItem(name: "Guess the Chord!", photo: photo1)!
        print("Menu items initialized")
        
        // add them to items array
        items += [theory, diffChord, guess]
        print("added into array")
        
        //MARK: remove later
        for item in items {
            print(item.name)
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
 
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
 
        return items.count
    }

    // configures and returns a table view cell
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        print("before table view cells reused")
        
        // Table view cells are reused and should be dequeued using a cell identifier.
        let cellIdentifier = "MenuTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! MenuTableViewCell
        print("after reused")
        
        // Fetch appropriate MenuTableViewCell
        let item = items[indexPath.row]
        print(item.name)

        
        //Set view to display data from MenuItem
        cell.textLabel!.text = item.name
        cell.imageView!.image = item.photo

        

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
