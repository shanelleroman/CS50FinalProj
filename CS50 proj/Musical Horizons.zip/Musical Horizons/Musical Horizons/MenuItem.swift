//
//  MenuItem.swift
//  MusicalHorizons
//
//  Created by Shanelle Roman on 12/4/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class MenuItem {
    
    //MARK: properties
    var name: String
    var photo: UIImage?
    
    //MARK: initalization
    init?(name: String, photo: UIImage?) {
        self.name = name
        self.photo = photo
        
        if name.isEmpty {
            return nil
        }
        
    }
    
}
