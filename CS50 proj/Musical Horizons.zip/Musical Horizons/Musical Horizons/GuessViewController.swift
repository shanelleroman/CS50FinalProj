//
//  GuessViewController.swift
//  MusicalHorizons
//  Controller for view where user guesses what chord is played
//  Information about what chord is to be played is passed from previous controller
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/8/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit
import AVFoundation

class GuessViewController: UIViewController, AVAudioPlayerDelegate {
    
    // MARK: properties
    var audioPlayer = AVAudioPlayer()
    var number: Int?


    //MARK: functions
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // Plays the sound when the button is pressed
    @IBAction func playChord(sender: AnyObject) {
        
        // Uses the random generated number to find approp file
        var name: String = ""
        if let numInt = number {
            switch numInt {
            case 0:
                name = "C_Major"
            case 1:
                name = "C_Minor"
            case 2:
                name = "C_7"
            default:
                break
            }

        }
        
        
        if name != "" {
            
            // Retrieves sound file's URL
            let soundURL =  NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource(name, ofType: "mp3")!)
           
            // Plays sound
            do {
                // set up audioPlayer
                audioPlayer = try AVAudioPlayer(contentsOfURL: soundURL)
                audioPlayer.delegate = self
                audioPlayer.volume = 1.0

                // play the sound
                audioPlayer.prepareToPlay()
                audioPlayer.play()
            }catch  {
                print("Error retrieving audio file")
            }
        }

    }

    // checks that the button pressed is correct
    func checkChordName(name: String) {
        var correct = ""

        // Uses the random generated number to find correct chord name
        if let numInt = number {
            switch numInt {
            case 0:
                correct = "Major Chord?"
            case 1:
                correct = "Minor Chord?"
            case 2:
                correct = "Dominant Chord?"
            default:
                break
            }
            
            // Checks the correct chord name against button name
            if name == correct {
                alertRight()
            } else {
                alertWrong()
            }
        
        }
    }

   
    // When Major Chord button pressed, triggers checking function
    @IBAction func checkMajor(sender: UIBarButtonItem) {
        // passes the button name as a String into checking function
        if let button = sender.title {
            checkChordName(button)
        }
    }
    


    // When Minor Chord button pressed, triggers checking function
    @IBAction func checkMinor(sender: UIBarButtonItem) {
        // passes the button name as a String into checking function
        if let button = sender.title {
            checkChordName(button)
        }
    }
    
    // When Dominant Chord pressed, triggers checking function
    @IBAction func checkDom(sender: UIBarButtonItem) {
        // passes the button name as a String into checking function
        if let button = sender.title {
            checkChordName(button)
        }
    }
    
    // changes the pseudorandom generated number to play a different Chord
    @IBAction func differentChord(sender: AnyObject) {
        
        // Makes sure the new chord is not the same as the old one
        let oldnum = number
        while number == oldnum {
            number = Int(arc4random_uniform(3))
        }
        
        
    }
    
    // Alerts the user if they picked the correct chord
    func alertRight() {
        // Initializes alert controller with message
        let alert = UIAlertController (title: "Correct!", message: "Click  Different chord to try again or Menu to go back", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "OK", style: .Default, handler: {
            (action: UIAlertAction!) in alert.dismissViewControllerAnimated(true, completion: nil)
        }))
        
        presentViewController(alert, animated: true, completion: nil)
        
    }
    
    // Alerts the user if they picked the wrong chord
    func alertWrong() {
        // Initializes alert controller with message
        let alert = UIAlertController (title: "Wrong!", message: "Click Play Sound to try again or Menu to go back", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "OK", style: .Default, handler: {
            (action: UIAlertAction!) in alert.dismissViewControllerAnimated(true, completion: nil)
        }))

        presentViewController(alert, animated: true, completion: nil)
        
    }
    
}
