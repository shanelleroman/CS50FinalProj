//
//  Key.swift
//  MusicalHorizons
//
//  Created by Shanelle Roman, Susanqi Jiang, and Edward Antonio on 12/7/15.
//  Copyright © 2015 Shanelle Roman. All rights reserved.
//

import UIKit

class Key {
    
    // MARK: properties
    var keyName: String
    var image: UIImage?
    
    //MARK: initialization
    init(keyName: String, image: UIImage?) {
        self.keyName = keyName
        self.image = image
    }
}
